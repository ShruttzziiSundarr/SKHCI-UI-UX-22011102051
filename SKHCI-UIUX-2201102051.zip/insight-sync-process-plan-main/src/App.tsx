
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import MainLayout from "./components/layout/MainLayout";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import Chat from "./pages/Chat";
import TeamManagement from "./pages/Team";
import Meetings from "./pages/Meetings";
import Analytics from "./pages/Analytics";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route 
            path="/dashboard" 
            element={
              <MainLayout>
                <Dashboard />
              </MainLayout>
            } 
          />
          <Route 
            path="/chat" 
            element={
              <MainLayout>
                <Chat />
              </MainLayout>
            } 
          />
          <Route 
            path="/team" 
            element={
              <MainLayout>
                <TeamManagement />
              </MainLayout>
            } 
          />
          <Route 
            path="/meetings" 
            element={
              <MainLayout>
                <Meetings />
              </MainLayout>
            } 
          />
          <Route 
            path="/notifications" 
            element={
              <MainLayout>
                <div className="p-6">
                  <h1 className="text-3xl font-bold mb-4">Notifications</h1>
                  <p className="text-muted-foreground">This feature is coming soon.</p>
                </div>
              </MainLayout>
            } 
          />
          <Route 
            path="/analytics" 
            element={
              <MainLayout>
                <Analytics />
              </MainLayout>
            } 
          />
          <Route 
            path="/settings" 
            element={
              <MainLayout>
                <div className="p-6">
                  <h1 className="text-3xl font-bold mb-4">Settings</h1>
                  <p className="text-muted-foreground">This feature is coming soon.</p>
                </div>
              </MainLayout>
            } 
          />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
