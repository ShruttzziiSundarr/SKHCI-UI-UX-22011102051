
import PendingWorkChart from "@/components/dashboard/PendingWorkChart";
import PerformanceChart from "@/components/dashboard/PerformanceChart";
import CompletedWorkChart from "@/components/dashboard/CompletedWorkChart";
import NotificationsChart from "@/components/dashboard/NotificationsChart";
import WorkloadDistributionChart from "@/components/dashboard/WorkloadDistributionChart";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Activity, 
  CheckCircle, 
  ClipboardCheck, 
  Users, 
  Calendar, 
  ArrowUpRight, 
  ArrowDownRight 
} from "lucide-react";

const stats = [
  { name: "Active Projects", value: 12, change: 3, increasing: true, icon: Activity },
  { name: "Tasks Completed", value: 342, change: 8, increasing: true, icon: CheckCircle },
  { name: "Team Members", value: 28, change: 2, increasing: true, icon: Users },
  { name: "Upcoming Deadlines", value: 8, change: 1, increasing: false, icon: Calendar },
];

const Dashboard = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back! Here's an overview of your team's performance.
        </p>
      </div>
      
      {/* Stats cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.name}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between space-x-2">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-muted rounded-full">
                    <stat.icon className="h-5 w-5 text-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-medium leading-none">{stat.name}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                </div>
                <div className={`flex items-center ${stat.increasing ? 'text-green-500' : 'text-red-500'}`}>
                  {stat.increasing ? (
                    <ArrowUpRight className="h-4 w-4 mr-1" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 mr-1" />
                  )}
                  <span className="text-sm font-medium">{stat.change}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Main charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PendingWorkChart />
        <PerformanceChart />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <CompletedWorkChart />
        <NotificationsChart />
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        <WorkloadDistributionChart />
      </div>
    </div>
  );
};

export default Dashboard;
