
import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

// Sample data for analytics charts
const performanceData = [
  { month: "Jan", efficiency: 78, target: 75 },
  { month: "Feb", efficiency: 80, target: 75 },
  { month: "Mar", efficiency: 77, target: 75 },
  { month: "Apr", efficiency: 83, target: 80 },
  { month: "May", efficiency: 85, target: 80 },
  { month: "Jun", efficiency: 82, target: 80 },
  { month: "Jul", efficiency: 87, target: 85 },
  { month: "Aug", efficiency: 89, target: 85 },
  { month: "Sep", efficiency: 91, target: 85 },
  { month: "Oct", efficiency: 88, target: 85 },
  { month: "Nov", efficiency: 92, target: 90 },
  { month: "Dec", efficiency: 94, target: 90 },
];

const taskCompletionData = [
  { month: "Jan", bugs: 45, features: 23, documents: 17 },
  { month: "Feb", bugs: 38, features: 27, documents: 21 },
  { month: "Mar", bugs: 42, features: 25, documents: 19 },
  { month: "Apr", bugs: 35, features: 30, documents: 23 },
  { month: "May", bugs: 30, features: 31, documents: 25 },
  { month: "Jun", bugs: 28, features: 36, documents: 22 },
  { month: "Jul", bugs: 25, features: 39, documents: 27 },
  { month: "Aug", bugs: 31, features: 33, documents: 24 },
  { month: "Sep", bugs: 27, features: 37, documents: 28 },
  { month: "Oct", bugs: 32, features: 35, documents: 26 },
  { month: "Nov", bugs: 23, features: 42, documents: 30 },
  { month: "Dec", bugs: 19, features: 45, documents: 32 },
];

const pendingTasksData = [
  { name: "High Priority", value: 18, color: "#ef4444" },
  { name: "Medium Priority", value: 32, color: "#f97316" },
  { name: "Low Priority", value: 24, color: "#22c55e" },
];

const notificationsData = [
  { name: "Mentions", value: 28, color: "#3b82f6" },
  { name: "Meeting Reminders", value: 32, color: "#a855f7" },
  { name: "Deadlines", value: 15, color: "#ef4444" },
  { name: "Project Updates", value: 25, color: "#22c55e" },
];

const workloadData = [
  { name: "Engineering", q1: 85, q2: 92, q3: 78, q4: 90 },
  { name: "Design", q1: 72, q2: 76, q3: 82, q4: 68 },
  { name: "Marketing", q1: 65, q2: 70, q3: 75, q4: 85 },
  { name: "Management", q1: 45, q2: 52, q3: 48, q4: 55 },
  { name: "HR", q1: 38, q2: 42, q3: 35, q4: 40 },
];

const projectSuccessData = [
  { name: "Project A", success: 85, failure: 15 },
  { name: "Project B", success: 72, failure: 28 },
  { name: "Project C", success: 90, failure: 10 },
  { name: "Project D", success: 65, failure: 35 },
  { name: "Project E", success: 78, failure: 22 },
];

const teamPerformanceData = [
  { name: "John", performance: 88, average: 75 },
  { name: "Jane", performance: 92, average: 75 },
  { name: "Mike", performance: 76, average: 75 },
  { name: "Sarah", performance: 85, average: 75 },
  { name: "Alex", performance: 79, average: 75 },
];

const Analytics = () => {
  const [timeRange, setTimeRange] = useState("year");

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
          <p className="text-muted-foreground">
            View detailed analytics and insights about your team's performance
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Select
            value={timeRange}
            onValueChange={setTimeRange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">Last Month</SelectItem>
              <SelectItem value="quarter">Last Quarter</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">Export</Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
                <CardDescription>Team efficiency over time compared to targets</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="efficiency" stroke="#3b82f6" activeDot={{ r: 8 }} name="Efficiency" />
                      <Line type="monotone" dataKey="target" stroke="#ef4444" strokeDasharray="5 5" name="Target" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pending Tasks</CardTitle>
                <CardDescription>Tasks breakdown by priority level</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pendingTasksData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {pendingTasksData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Completed Tasks</CardTitle>
                <CardDescription>Tasks completed by category over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={taskCompletionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="bugs" stackId="a" fill="#ef4444" name="Bug Fixes" />
                      <Bar dataKey="features" stackId="a" fill="#3b82f6" name="New Features" />
                      <Bar dataKey="documents" stackId="a" fill="#22c55e" name="Documents" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>Breakdown of notifications by type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={notificationsData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {notificationsData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Performance Tab */}
        <TabsContent value="performance">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Team Performance</CardTitle>
                <CardDescription>Individual performance compared to team average</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={teamPerformanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="performance" fill="#3b82f6" name="Performance Score" />
                      <Bar dataKey="average" fill="#ef4444" name="Team Average" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Workload Distribution</CardTitle>
                <CardDescription>Department workload by quarter</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={workloadData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Area type="monotone" dataKey="q1" stackId="1" fill="#3b82f6" stroke="#3b82f6" name="Q1" />
                      <Area type="monotone" dataKey="q2" stackId="1" fill="#a855f7" stroke="#a855f7" name="Q2" />
                      <Area type="monotone" dataKey="q3" stackId="1" fill="#22c55e" stroke="#22c55e" name="Q3" />
                      <Area type="monotone" dataKey="q4" stackId="1" fill="#f97316" stroke="#f97316" name="Q4" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Efficiency Trends</CardTitle>
                <CardDescription>Team efficiency over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis domain={[60, 100]} />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="efficiency" stroke="#3b82f6" activeDot={{ r: 8 }} name="Efficiency" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Tasks Tab */}
        <TabsContent value="tasks">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Task Completion Over Time</CardTitle>
                <CardDescription>Tasks completed by category each month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={taskCompletionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="bugs" fill="#ef4444" name="Bug Fixes" />
                      <Bar dataKey="features" fill="#3b82f6" name="New Features" />
                      <Bar dataKey="documents" fill="#22c55e" name="Documents" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Task Distribution</CardTitle>
                <CardDescription>Current breakdown of tasks by priority</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pendingTasksData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {pendingTasksData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Task Trends</CardTitle>
                <CardDescription>Task volume over time by category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={taskCompletionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="bugs" stroke="#ef4444" name="Bug Fixes" />
                      <Line type="monotone" dataKey="features" stroke="#3b82f6" name="New Features" />
                      <Line type="monotone" dataKey="documents" stroke="#22c55e" name="Documents" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Projects Tab */}
        <TabsContent value="projects">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Project Success Rates</CardTitle>
                <CardDescription>Success vs failure rates for recent projects</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={projectSuccessData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="success" stackId="a" fill="#22c55e" name="Success Rate" />
                      <Bar dataKey="failure" stackId="a" fill="#ef4444" name="Failure Rate" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Project Workload</CardTitle>
                <CardDescription>Workload distribution across departments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={workloadData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="q1" fill="#3b82f6" name="Q1" />
                      <Bar dataKey="q2" fill="#a855f7" name="Q2" />
                      <Bar dataKey="q3" fill="#22c55e" name="Q3" />
                      <Bar dataKey="q4" fill="#f97316" name="Q4" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Project Success Factors</CardTitle>
                <CardDescription>Contributing factors to project success</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Team Skill", value: 35, color: "#3b82f6" },
                          { name: "Communication", value: 25, color: "#a855f7" },
                          { name: "Planning", value: 20, color: "#22c55e" },
                          { name: "Resources", value: 15, color: "#f97316" },
                          { name: "Client Factors", value: 5, color: "#ef4444" },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {[
                          { name: "Team Skill", value: 35, color: "#3b82f6" },
                          { name: "Communication", value: 25, color: "#a855f7" },
                          { name: "Planning", value: 20, color: "#22c55e" },
                          { name: "Resources", value: 15, color: "#f97316" },
                          { name: "Client Factors", value: 5, color: "#ef4444" },
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Analytics;
