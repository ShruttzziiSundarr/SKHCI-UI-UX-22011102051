
import { useState, useEffect } from "react";
import ChatSidebar from "@/components/chat/ChatSidebar";
import ChatWindow from "@/components/chat/ChatWindow";
import { useToast } from "@/hooks/use-toast";

const Chat = () => {
  const { toast } = useToast();
  const [isLoaded, setIsLoaded] = useState(false);
  
  useEffect(() => {
    // Simulate loading chat data
    const timer = setTimeout(() => {
      setIsLoaded(true);
      toast({
        title: "Chat connected",
        description: "You are now connected to the chat system",
      });
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [toast]);

  return (
    <div className="flex h-[calc(100vh-80px)] -m-6 overflow-hidden border border-border rounded-lg">
      <ChatSidebar />
      <div className="flex-1">
        {isLoaded ? (
          <ChatWindow />
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="animate-pulse flex flex-col items-center">
              <div className="h-12 w-12 bg-muted rounded-full mb-4"></div>
              <div className="h-4 w-48 bg-muted rounded mb-2"></div>
              <div className="h-3 w-36 bg-muted rounded"></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chat;
