
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageSquare, BarChart3, Users, Calendar } from "lucide-react";

const features = [
  {
    name: "Interactive Chat System",
    description: "Private and group messaging, meeting scheduling, and smart notifications",
    icon: MessageSquare,
    color: "bg-blue-100 text-blue-700",
    link: "/chat"
  },
  {
    name: "Statistical Dashboards",
    description: "Visualize tasks, performance trends, and work completion metrics",
    icon: BarChart3,
    color: "bg-purple-100 text-purple-700",
    link: "/dashboard"
  },
  {
    name: "Team Collaboration",
    description: "Connect with your team, manage workloads, and track progress together",
    icon: Users,
    color: "bg-green-100 text-green-700",
    link: "/team"
  },
  {
    name: "Calendar & Scheduling",
    description: "Schedule meetings, manage room allocations, and set deadlines",
    icon: Calendar,
    color: "bg-orange-100 text-orange-700",
    link: "/meetings"
  }
];

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
        <h1 className="text-5xl font-bold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-brand-primary to-brand-accent">
          InsightSync
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mb-10">
          A powerful and intuitive collaboration platform that combines communication
          and data visualization to boost team productivity.
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Button
            size="lg"
            onClick={() => navigate("/dashboard")}
            className="bg-brand-primary hover:bg-brand-primary/90"
          >
            <BarChart3 className="mr-2 h-5 w-5" />
            View Dashboard
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => navigate("/chat")}
          >
            <MessageSquare className="mr-2 h-5 w-5" />
            Go to Chat
          </Button>
        </div>
      </div>

      {/* Features section */}
      <div className="py-16 px-4 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <Card key={feature.name} className="border shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className={`w-12 h-12 rounded-full ${feature.color} flex items-center justify-center mb-4`}>
                    <feature.icon size={24} />
                  </div>
                  <CardTitle>{feature.name}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="ghost" 
                    className="text-brand-primary"
                    onClick={() => navigate(feature.link)}
                  >
                    Explore Feature
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Start Collaborating Smarter Today</h2>
          <p className="text-muted-foreground mb-8">
            Streamline your workflow, enhance team collaboration, and visualize your progress
            all in one place.
          </p>
          <Button 
            size="lg" 
            className="bg-brand-primary hover:bg-brand-primary/90"
            onClick={() => navigate("/dashboard")}
          >
            Get Started
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Index;
