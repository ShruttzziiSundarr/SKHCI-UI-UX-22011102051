
import { useState } from "react";
import { Calendar, Clock, MapPin, Users, PlusCircle, Edit, Trash2 } from "lucide-react";
import { format, parseISO, addHours } from "date-fns";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";

// Define interface for meeting room
interface Room {
  id: number;
  name: string;
  capacity: number;
  equipment: string[];
}

// Define interface for meeting
interface Meeting {
  id: number;
  title: string;
  room: string;
  date: string;
  startTime: string;
  endTime: string;
  attendees: string[];
  description: string;
}

// Sample meeting rooms
const rooms: Room[] = [
  { id: 1, name: "Conference Room A", capacity: 20, equipment: ["Projector", "Whiteboard", "Video Conferencing"] },
  { id: 2, name: "Conference Room B", capacity: 12, equipment: ["TV Screen", "Whiteboard"] },
  { id: 3, name: "Executive Boardroom", capacity: 8, equipment: ["Video Conferencing", "Smart Board"] },
  { id: 4, name: "Brainstorm Room", capacity: 6, equipment: ["Whiteboard", "Flipcharts"] },
  { id: 5, name: "Training Room", capacity: 30, equipment: ["Projector", "Multiple Screens", "Audio System"] },
];

// Sample initial meetings
const initialMeetings: Meeting[] = [
  { 
    id: 1, 
    title: "Weekly Team Sync", 
    room: "Conference Room A", 
    date: "2025-04-05", 
    startTime: "09:00", 
    endTime: "10:00",
    attendees: ["John Doe", "Jane Smith", "Mike Johnson"],
    description: "Weekly team sync to discuss progress and blockers."
  },
  { 
    id: 2, 
    title: "Project Planning", 
    room: "Executive Boardroom", 
    date: "2025-04-06", 
    startTime: "13:00", 
    endTime: "14:30",
    attendees: ["John Doe", "Sarah Williams", "Alex Brown"],
    description: "Plan the next phase of the project and assign responsibilities."
  },
  { 
    id: 3, 
    title: "Client Presentation", 
    room: "Conference Room B", 
    date: "2025-04-07", 
    startTime: "11:00", 
    endTime: "12:00",
    attendees: ["John Doe", "Jane Smith", "Mike Johnson", "Sarah Williams"],
    description: "Present the project progress to the client."
  },
];

const Meetings = () => {
  const [meetings, setMeetings] = useState<Meeting[]>(initialMeetings);
  const [newMeeting, setNewMeeting] = useState<Meeting>({
    id: 0,
    title: "",
    room: "",
    date: "",
    startTime: "",
    endTime: "",
    attendees: [],
    description: ""
  });
  const [editingMeeting, setEditingMeeting] = useState<Meeting | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [tab, setTab] = useState("upcoming");
  const [attendee, setAttendee] = useState("");
  const { toast } = useToast();

  const upcomingMeetings = meetings.filter(meeting => {
    const meetingDateTime = new Date(`${meeting.date}T${meeting.startTime}`);
    return meetingDateTime.getTime() >= new Date().getTime();
  }).sort((a, b) => {
    const aDateTime = new Date(`${a.date}T${a.startTime}`).getTime();
    const bDateTime = new Date(`${b.date}T${b.startTime}`).getTime();
    return aDateTime - bDateTime;
  });

  const pastMeetings = meetings.filter(meeting => {
    const meetingDateTime = new Date(`${meeting.date}T${meeting.startTime}`);
    return meetingDateTime.getTime() < new Date().getTime();
  }).sort((a, b) => {
    const aDateTime = new Date(`${a.date}T${a.startTime}`).getTime();
    const bDateTime = new Date(`${b.date}T${b.startTime}`).getTime();
    return bDateTime - aDateTime;
  });

  const dateSpecificMeetings = meetings.filter(meeting => 
    meeting.date === format(selectedDate, 'yyyy-MM-dd')
  ).sort((a, b) => a.startTime.localeCompare(b.startTime));

  const handleAddMeeting = () => {
    if (!newMeeting.title || !newMeeting.room || !newMeeting.date || !newMeeting.startTime || !newMeeting.endTime) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Check if end time is after start time
    if (newMeeting.startTime >= newMeeting.endTime) {
      toast({
        title: "Invalid time",
        description: "End time must be after start time",
        variant: "destructive"
      });
      return;
    }

    const id = meetings.length ? Math.max(...meetings.map(m => m.id)) + 1 : 1;
    setMeetings([...meetings, { ...newMeeting, id }]);
    setNewMeeting({
      id: 0,
      title: "",
      room: "",
      date: "",
      startTime: "",
      endTime: "",
      attendees: [],
      description: ""
    });

    toast({
      title: "Meeting scheduled",
      description: `${newMeeting.title} has been scheduled in ${newMeeting.room}`,
    });
  };

  const handleAddAttendee = () => {
    if (!attendee) return;
    if (editingMeeting) {
      if (!editingMeeting.attendees.includes(attendee)) {
        setEditingMeeting({
          ...editingMeeting,
          attendees: [...editingMeeting.attendees, attendee]
        });
      }
    } else {
      if (!newMeeting.attendees.includes(attendee)) {
        setNewMeeting({
          ...newMeeting,
          attendees: [...newMeeting.attendees, attendee]
        });
      }
    }
    setAttendee("");
  };

  const handleRemoveAttendee = (person: string) => {
    if (editingMeeting) {
      setEditingMeeting({
        ...editingMeeting,
        attendees: editingMeeting.attendees.filter(a => a !== person)
      });
    } else {
      setNewMeeting({
        ...newMeeting,
        attendees: newMeeting.attendees.filter(a => a !== person)
      });
    }
  };

  const handleEditMeeting = (meeting: Meeting) => {
    setEditingMeeting(meeting);
  };

  const handleSaveEdit = () => {
    if (!editingMeeting) return;
    
    if (!editingMeeting.title || !editingMeeting.room || !editingMeeting.date || !editingMeeting.startTime || !editingMeeting.endTime) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Check if end time is after start time
    if (editingMeeting.startTime >= editingMeeting.endTime) {
      toast({
        title: "Invalid time",
        description: "End time must be after start time",
        variant: "destructive"
      });
      return;
    }

    setMeetings(meetings.map(meeting => 
      meeting.id === editingMeeting.id ? editingMeeting : meeting
    ));
    setEditingMeeting(null);
    
    toast({
      title: "Meeting updated",
      description: `${editingMeeting.title} has been updated`,
    });
  };

  const handleDeleteMeeting = (id: number) => {
    const meetingToDelete = meetings.find(m => m.id === id);
    if (!meetingToDelete) return;
    
    setMeetings(meetings.filter(meeting => meeting.id !== id));
    
    toast({
      title: "Meeting canceled",
      description: `${meetingToDelete.title} has been canceled`,
    });
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    return `${hours}:${minutes}`;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Meetings & Scheduling</h1>
        <p className="text-muted-foreground">
          Manage your meetings, schedule new ones, and allocate rooms
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Meetings</CardTitle>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Schedule Meeting
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>Schedule New Meeting</DialogTitle>
                    <DialogDescription>
                      Fill in the details to schedule a new meeting
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="title" className="text-right">
                        Title
                      </Label>
                      <Input
                        id="title"
                        value={newMeeting.title}
                        onChange={(e) => setNewMeeting({...newMeeting, title: e.target.value})}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="room" className="text-right">
                        Room
                      </Label>
                      <Select
                        onValueChange={(value) => setNewMeeting({...newMeeting, room: value})}
                        value={newMeeting.room}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select room" />
                        </SelectTrigger>
                        <SelectContent>
                          {rooms.map(room => (
                            <SelectItem key={room.id} value={room.name}>
                              {room.name} (Capacity: {room.capacity})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="date" className="text-right">
                        Date
                      </Label>
                      <Input
                        id="date"
                        type="date"
                        value={newMeeting.date}
                        onChange={(e) => setNewMeeting({...newMeeting, date: e.target.value})}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="startTime" className="text-right">
                        Start Time
                      </Label>
                      <Input
                        id="startTime"
                        type="time"
                        value={newMeeting.startTime}
                        onChange={(e) => setNewMeeting({...newMeeting, startTime: e.target.value})}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="endTime" className="text-right">
                        End Time
                      </Label>
                      <Input
                        id="endTime"
                        type="time"
                        value={newMeeting.endTime}
                        onChange={(e) => setNewMeeting({...newMeeting, endTime: e.target.value})}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-start gap-4">
                      <Label htmlFor="attendees" className="text-right pt-2">
                        Attendees
                      </Label>
                      <div className="col-span-3 space-y-2">
                        <div className="flex space-x-2">
                          <Input
                            id="attendees"
                            placeholder="Add attendee name"
                            value={attendee}
                            onChange={(e) => setAttendee(e.target.value)}
                          />
                          <Button type="button" onClick={handleAddAttendee} variant="secondary">
                            Add
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {newMeeting.attendees.map((person, index) => (
                            <Badge key={index} variant="secondary" className="flex items-center gap-1">
                              {person}
                              <button
                                type="button"
                                onClick={() => handleRemoveAttendee(person)}
                                className="ml-1 hover:text-destructive"
                              >
                                ×
                              </button>
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 items-start gap-4">
                      <Label htmlFor="description" className="text-right pt-2">
                        Description
                      </Label>
                      <Textarea
                        id="description"
                        value={newMeeting.description}
                        onChange={(e) => setNewMeeting({...newMeeting, description: e.target.value})}
                        className="col-span-3"
                        rows={3}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button onClick={handleAddMeeting}>Schedule Meeting</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="upcoming" className="w-full" onValueChange={setTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="calendar">Calendar</TabsTrigger>
                <TabsTrigger value="past">Past</TabsTrigger>
              </TabsList>
              <TabsContent value="upcoming">
                {upcomingMeetings.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No upcoming meetings scheduled
                  </div>
                ) : (
                  <div className="space-y-4 mt-4">
                    {upcomingMeetings.map((meeting) => (
                      <Card key={meeting.id}>
                        <CardContent className="py-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">{meeting.title}</h3>
                              <div className="flex items-center text-muted-foreground mt-1">
                                <Calendar className="h-4 w-4 mr-1" />
                                <span className="mr-4">
                                  {format(parseISO(meeting.date), 'MMMM d, yyyy')}
                                </span>
                                <Clock className="h-4 w-4 mr-1" />
                                <span>
                                  {formatTime(meeting.startTime)} - {formatTime(meeting.endTime)}
                                </span>
                              </div>
                              <div className="flex items-center text-muted-foreground mt-1">
                                <MapPin className="h-4 w-4 mr-1" />
                                <span className="mr-4">{meeting.room}</span>
                                <Users className="h-4 w-4 mr-1" />
                                <span>{meeting.attendees.length} attendees</span>
                              </div>
                              {meeting.description && (
                                <p className="mt-2 text-sm">{meeting.description}</p>
                              )}
                            </div>
                            <div className="flex space-x-1">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="ghost" size="icon" onClick={() => handleEditMeeting(meeting)}>
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-3xl">
                                  <DialogHeader>
                                    <DialogTitle>Edit Meeting</DialogTitle>
                                    <DialogDescription>
                                      Update the meeting details
                                    </DialogDescription>
                                  </DialogHeader>
                                  {editingMeeting && (
                                    <div className="grid gap-4 py-4">
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-title" className="text-right">
                                          Title
                                        </Label>
                                        <Input
                                          id="edit-title"
                                          value={editingMeeting.title}
                                          onChange={(e) => setEditingMeeting({...editingMeeting, title: e.target.value})}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-room" className="text-right">
                                          Room
                                        </Label>
                                        <Select
                                          onValueChange={(value) => setEditingMeeting({...editingMeeting, room: value})}
                                          value={editingMeeting.room}
                                        >
                                          <SelectTrigger className="col-span-3">
                                            <SelectValue placeholder="Select room" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            {rooms.map(room => (
                                              <SelectItem key={room.id} value={room.name}>
                                                {room.name} (Capacity: {room.capacity})
                                              </SelectItem>
                                            ))}
                                          </SelectContent>
                                        </Select>
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-date" className="text-right">
                                          Date
                                        </Label>
                                        <Input
                                          id="edit-date"
                                          type="date"
                                          value={editingMeeting.date}
                                          onChange={(e) => setEditingMeeting({...editingMeeting, date: e.target.value})}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-startTime" className="text-right">
                                          Start Time
                                        </Label>
                                        <Input
                                          id="edit-startTime"
                                          type="time"
                                          value={editingMeeting.startTime}
                                          onChange={(e) => setEditingMeeting({...editingMeeting, startTime: e.target.value})}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-endTime" className="text-right">
                                          End Time
                                        </Label>
                                        <Input
                                          id="edit-endTime"
                                          type="time"
                                          value={editingMeeting.endTime}
                                          onChange={(e) => setEditingMeeting({...editingMeeting, endTime: e.target.value})}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-start gap-4">
                                        <Label htmlFor="edit-attendees" className="text-right pt-2">
                                          Attendees
                                        </Label>
                                        <div className="col-span-3 space-y-2">
                                          <div className="flex space-x-2">
                                            <Input
                                              id="edit-attendees"
                                              placeholder="Add attendee name"
                                              value={attendee}
                                              onChange={(e) => setAttendee(e.target.value)}
                                            />
                                            <Button type="button" onClick={handleAddAttendee} variant="secondary">
                                              Add
                                            </Button>
                                          </div>
                                          <div className="flex flex-wrap gap-2">
                                            {editingMeeting.attendees.map((person, index) => (
                                              <Badge key={index} variant="secondary" className="flex items-center gap-1">
                                                {person}
                                                <button
                                                  type="button"
                                                  onClick={() => handleRemoveAttendee(person)}
                                                  className="ml-1 hover:text-destructive"
                                                >
                                                  ×
                                                </button>
                                              </Badge>
                                            ))}
                                          </div>
                                        </div>
                                      </div>
                                      <div className="grid grid-cols-4 items-start gap-4">
                                        <Label htmlFor="edit-description" className="text-right pt-2">
                                          Description
                                        </Label>
                                        <Textarea
                                          id="edit-description"
                                          value={editingMeeting.description}
                                          onChange={(e) => setEditingMeeting({...editingMeeting, description: e.target.value})}
                                          className="col-span-3"
                                          rows={3}
                                        />
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button onClick={handleSaveEdit}>Save Changes</Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleDeleteMeeting(meeting.id)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
              <TabsContent value="calendar">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  <div>
                    <CalendarComponent
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => date && setSelectedDate(date)}
                      className="rounded-md border"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium mb-4">
                      {format(selectedDate, 'MMMM d, yyyy')}
                    </h3>
                    {dateSpecificMeetings.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        No meetings scheduled for this day
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {dateSpecificMeetings.map((meeting) => (
                          <Card key={meeting.id}>
                            <CardContent className="py-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-semibold">{meeting.title}</h3>
                                  <div className="flex items-center text-muted-foreground mt-1">
                                    <Clock className="h-4 w-4 mr-1" />
                                    <span className="mr-4">
                                      {formatTime(meeting.startTime)} - {formatTime(meeting.endTime)}
                                    </span>
                                  </div>
                                  <div className="flex items-center text-muted-foreground mt-1">
                                    <MapPin className="h-4 w-4 mr-1" />
                                    <span>{meeting.room}</span>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="past">
                {pastMeetings.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No past meetings
                  </div>
                ) : (
                  <div className="space-y-4 mt-4">
                    {pastMeetings.map((meeting) => (
                      <Card key={meeting.id} className="opacity-75">
                        <CardContent className="py-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">{meeting.title}</h3>
                              <div className="flex items-center text-muted-foreground mt-1">
                                <Calendar className="h-4 w-4 mr-1" />
                                <span className="mr-4">
                                  {format(parseISO(meeting.date), 'MMMM d, yyyy')}
                                </span>
                                <Clock className="h-4 w-4 mr-1" />
                                <span>
                                  {formatTime(meeting.startTime)} - {formatTime(meeting.endTime)}
                                </span>
                              </div>
                              <div className="flex items-center text-muted-foreground mt-1">
                                <MapPin className="h-4 w-4 mr-1" />
                                <span className="mr-4">{meeting.room}</span>
                                <Users className="h-4 w-4 mr-1" />
                                <span>{meeting.attendees.length} attendees</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Available Rooms</CardTitle>
            <CardDescription>View room details and equipment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {rooms.map((room) => (
                <Card key={room.id}>
                  <CardContent className="py-4">
                    <h3 className="font-semibold">{room.name}</h3>
                    <div className="flex items-center text-muted-foreground mt-1">
                      <Users className="h-4 w-4 mr-1" />
                      <span>Capacity: {room.capacity}</span>
                    </div>
                    <div className="mt-2">
                      <h4 className="text-sm font-medium mb-1">Equipment:</h4>
                      <div className="flex flex-wrap gap-2">
                        {room.equipment.map((item, i) => (
                          <Badge key={i} variant="outline">{item}</Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Meetings;
