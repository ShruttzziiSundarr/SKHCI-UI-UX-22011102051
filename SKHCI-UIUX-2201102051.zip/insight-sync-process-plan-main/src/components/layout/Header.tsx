
import { useState, useEffect } from "react";
import { 
  Bell, 
  Search, 
  MessageSquare, 
  ChevronDown,
  Moon,
  Sun
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Avatar,
  AvatarFallback,
  AvatarImage
} from "@/components/ui/avatar";
import { Toggle } from "@/components/ui/toggle";

const Header: React.FC = () => {
  const [notifications, setNotifications] = useState(3);
  const [messages, setMessages] = useState(2);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Check for user's preferred color scheme on component mount
  useEffect(() => {
    // Check if the user has a saved preference
    const savedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    
    if (savedTheme === "dark" || (!savedTheme && prefersDark)) {
      setIsDarkMode(true);
      document.documentElement.classList.add("dark");
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove("dark");
    }
  }, []);

  // Toggle dark mode
  const toggleDarkMode = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    } else {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    }
    setIsDarkMode(!isDarkMode);
  };

  return (
    <header className="h-16 px-4 border-b border-border flex items-center justify-between bg-background">
      <div className="flex items-center w-full max-w-md">
        <div className="relative w-full">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search..." 
            className="pl-8 bg-muted/40"
          />
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <Toggle 
          aria-label="Toggle dark mode"
          pressed={isDarkMode}
          onPressedChange={toggleDarkMode}
          className="border border-border"
        >
          {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
        </Toggle>
        
        <Button variant="ghost" size="icon" className="relative">
          <MessageSquare size={20} />
          {messages > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0"
            >
              {messages}
            </Badge>
          )}
        </Button>
        
        <Button variant="ghost" size="icon" className="relative">
          <Bell size={20} />
          {notifications > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0"
            >
              {notifications}
            </Badge>
          )}
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center space-x-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src="" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="flex items-center">
                <span className="text-sm font-medium">John Doe</span>
                <ChevronDown size={16} className="ml-1" />
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default Header;
