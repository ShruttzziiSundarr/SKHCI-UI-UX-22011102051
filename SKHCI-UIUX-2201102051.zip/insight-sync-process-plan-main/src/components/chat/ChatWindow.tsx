
import { useState, useRef, useEffect } from "react";
import { 
  Send, 
  Paperclip, 
  Smile, 
  MoreVertical, 
  PhoneCall, 
  Video, 
  Search,
  AtSign,
  Calendar,
  Tag 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";

// Define message interface for type safety
interface Message {
  id: number;
  sender: string;
  text: string;
  time: string;
  isMine: boolean;
  hasMention?: boolean;
  hasAttachment?: boolean;
}

// Sample data for the chat
const initialMessages = [
  { id: 1, sender: "Alice Smith", text: "Hi there! How's the project coming along?", time: "10:30 AM", isMine: false },
  { id: 2, sender: "You", text: "Hey Alice! It's going well. We're on track to meet the deadline.", time: "10:32 AM", isMine: true },
  { id: 3, sender: "Alice Smith", text: "That's great to hear! Do you have the latest mockups ready?", time: "10:33 AM", isMine: false },
  { id: 4, sender: "You", text: "Yes, I just finished them. I'll share them with you right away.", time: "10:35 AM", isMine: true },
  { id: 5, sender: "Alice Smith", text: "Perfect! Also, don't forget we have a team meeting @everyone tomorrow at 2 PM to discuss the next phase of the project.", time: "10:36 AM", isMine: false, hasMention: true },
  { id: 6, sender: "You", text: "I've noted it down. I'll make sure to prepare a short presentation on our progress.", time: "10:38 AM", isMine: true },
  { id: 7, sender: "Alice Smith", text: "That would be great! Looking forward to it.", time: "10:40 AM", isMine: false },
  { id: 8, sender: "You", text: "Here are the mockups we discussed. Let me know what you think!", time: "10:42 AM", isMine: true, hasAttachment: true },
];

const formatMessageText = (text: string) => {
  // Replace @mentions with styled spans
  const mentionRegex = /(@\w+)/g;
  const parts = text.split(mentionRegex);
  
  return parts.map((part, index) => {
    if (part.match(mentionRegex)) {
      return (
        <Badge key={index} variant="secondary" className="font-normal mr-1">
          {part}
        </Badge>
      );
    }
    return <span key={index}>{part}</span>;
  });
};

const ChatWindow = () => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // Create a new message
      const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const hasMention = /@\w+/.test(newMessage);
      
      const newMessageObj: Message = {
        id: messages.length + 1,
        sender: "You",
        text: newMessage,
        time: currentTime,
        isMine: true,
        hasMention: hasMention
      };
      
      // Update messages state
      setMessages([...messages, newMessageObj]);
      setNewMessage("");
      
      // Show a toast when mentioning someone
      if (hasMention) {
        toast({
          title: "Mention sent",
          description: "Your mention has been sent successfully.",
        });
      }
    }
  };
  
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  const handleAttachFile = () => {
    toast({
      title: "Attachment",
      description: "File attachment feature clicked.",
    });
  };
  
  const handleMention = () => {
    setNewMessage(prev => `${prev} @`);
    toast({
      description: "Type a username after the @ symbol.",
    });
  };
  
  const handleScheduleMeeting = () => {
    toast({
      title: "Schedule Meeting",
      description: "Meeting scheduler will open soon.",
    });
  };
  
  const handleAddTag = () => {
    toast({
      title: "Add Tag",
      description: "Tag selector will open soon.",
    });
  };
  
  return (
    <div className="flex flex-col h-full">
      {/* Chat header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-border">
        <div className="flex items-center">
          <Avatar className="h-10 w-10 mr-3">
            <AvatarImage src="" />
            <AvatarFallback>AS</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-medium">Alice Smith</h3>
            <span className="text-xs text-muted-foreground">Online</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Search size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Search in conversation</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon">
                  <PhoneCall size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Call</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Video size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Video call</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical size={18} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>View profile</DropdownMenuItem>
              <DropdownMenuItem>Mute notifications</DropdownMenuItem>
              <DropdownMenuItem>Block user</DropdownMenuItem>
              <DropdownMenuItem>Clear chat history</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Chat messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isMine ? "justify-end" : "justify-start"}`}
            >
              <div className="flex max-w-[80%]">
                {!message.isMine && (
                  <Avatar className="h-8 w-8 mr-2 mt-1">
                    <AvatarFallback>AS</AvatarFallback>
                  </Avatar>
                )}
                
                <div>
                  <div className={`flex items-center ${message.isMine ? "justify-end" : "justify-start"}`}>
                    {!message.isMine && <span className="text-sm font-medium mr-2">{message.sender}</span>}
                    <span className="text-xs text-muted-foreground">{message.time}</span>
                  </div>
                  
                  <div 
                    className={`mt-1 px-4 py-2 rounded-lg ${
                      message.isMine 
                        ? "bg-brand-primary text-white" 
                        : "bg-muted"
                    }`}
                  >
                    <div className="text-sm">
                      {message.hasMention ? formatMessageText(message.text) : message.text}
                    </div>
                    
                    {message.hasAttachment && (
                      <div className="mt-2 p-2 bg-background/10 rounded border border-background/20 flex items-center">
                        <div className="w-8 h-8 bg-background/20 rounded flex items-center justify-center mr-2">
                          <Paperclip size={16} />
                        </div>
                        <div>
                          <div className="text-xs font-medium">project-mockups.zip</div>
                          <div className="text-xs opacity-80">2.4 MB</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
      
      {/* Message input */}
      <div className="px-4 py-3 border-t border-border">
        <div className="flex items-center space-x-2">
          <Input
            className="flex-1"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" onClick={handleAttachFile}>
                  <Paperclip size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Attach file</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" onClick={handleMention}>
                  <AtSign size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Mention user</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" onClick={handleScheduleMeeting}>
                  <Calendar size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Schedule meeting</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" onClick={handleAddTag}>
                  <Tag size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Add tag</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Smile size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Emoji</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <Button size="icon" onClick={handleSendMessage}>
            <Send size={18} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
