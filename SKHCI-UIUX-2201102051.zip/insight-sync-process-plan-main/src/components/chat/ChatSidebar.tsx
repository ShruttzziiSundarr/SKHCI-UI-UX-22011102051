
import { useState } from "react";
import { Search, Plus, User, Users, CalendarClock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";

// Sample data interfaces
interface PrivateChat {
  id: number;
  name: string;
  lastMessage: string;
  time: string;
  unread: number;
  online: boolean;
  isActive?: boolean;
}

interface GroupChat {
  id: number;
  name: string;
  lastMessage: string;
  time: string;
  unread: number;
  members: number;
  isActive?: boolean;
}

interface Meeting {
  id: number;
  name: string;
  time: string;
  participants: number;
  isActive?: boolean;
}

// Sample data
const initialPrivateChats: PrivateChat[] = [
  { id: 1, name: "Alice Smith", lastMessage: "Can you send those files?", time: "10:30 AM", unread: 2, online: true, isActive: true },
  { id: 2, name: "Bob Johnson", lastMessage: "Meeting at 2pm today", time: "9:15 AM", unread: 0, online: true },
  { id: 3, name: "Charlie Brown", lastMessage: "Thanks for your help!", time: "Yesterday", unread: 0, online: false },
  { id: 4, name: "Diana Lewis", lastMessage: "Let's discuss tomorrow", time: "Yesterday", unread: 1, online: false },
  { id: 5, name: "Ethan Hunt", lastMessage: "Project deadline extended", time: "Monday", unread: 0, online: true },
];

const initialGroupChats: GroupChat[] = [
  { id: 101, name: "Project Alpha", lastMessage: "Dave: Updated the roadmap", time: "11:45 AM", unread: 3, members: 5 },
  { id: 102, name: "Marketing Team", lastMessage: "Jane: Campaign stats are in", time: "Yesterday", unread: 0, members: 8 },
  { id: 103, name: "Office Fun", lastMessage: "Frank: Who's up for lunch?", time: "Monday", unread: 0, members: 15 },
];

const initialMeetings: Meeting[] = [
  { id: 201, name: "Weekly Standup", time: "Today, 2:00 PM", participants: 8 },
  { id: 202, name: "Product Review", time: "Tomorrow, 10:00 AM", participants: 5 },
  { id: 203, name: "Budget Planning", time: "Friday, 1:30 PM", participants: 4 },
];

const ChatSidebar = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("private");
  const [privateChats, setPrivateChats] = useState<PrivateChat[]>(initialPrivateChats);
  const [groupChats, setGroupChats] = useState<GroupChat[]>(initialGroupChats);
  const [meetings, setMeetings] = useState<Meeting[]>(initialMeetings);
  const { toast } = useToast();
  
  // Filter chats based on search query
  const filteredPrivateChats = privateChats.filter(chat => 
    chat.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    chat.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredGroupChats = groupChats.filter(chat => 
    chat.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    chat.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredMeetings = meetings.filter(meeting => 
    meeting.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleChatSelect = (type: string, id: number) => {
    if (type === 'private') {
      setPrivateChats(prev => prev.map(chat => ({
        ...chat,
        isActive: chat.id === id,
        unread: chat.id === id ? 0 : chat.unread // Mark as read when selected
      })));
      // Reset active state for other tabs
      setGroupChats(prev => prev.map(chat => ({ ...chat, isActive: false })));
      setMeetings(prev => prev.map(meeting => ({ ...meeting, isActive: false })));
    } else if (type === 'group') {
      setGroupChats(prev => prev.map(chat => ({
        ...chat,
        isActive: chat.id === id,
        unread: chat.id === id ? 0 : chat.unread // Mark as read when selected
      })));
      // Reset active state for other tabs
      setPrivateChats(prev => prev.map(chat => ({ ...chat, isActive: false })));
      setMeetings(prev => prev.map(meeting => ({ ...meeting, isActive: false })));
    } else if (type === 'meeting') {
      setMeetings(prev => prev.map(meeting => ({
        ...meeting,
        isActive: meeting.id === id
      })));
      // Reset active state for other tabs
      setPrivateChats(prev => prev.map(chat => ({ ...chat, isActive: false })));
      setGroupChats(prev => prev.map(chat => ({ ...chat, isActive: false })));
    }
  };
  
  const handleNewChat = () => {
    toast({
      title: "New Conversation",
      description: "Create a new chat or group.",
    });
  };
  
  return (
    <div className="w-80 border-r border-border flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-lg">Messages</h2>
          <Button size="icon" variant="ghost" onClick={handleNewChat}>
            <Plus size={18} />
          </Button>
        </div>
        <div className="relative">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search conversations..." 
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      <Tabs 
        defaultValue="private" 
        value={activeTab}
        onValueChange={setActiveTab}
        className="flex-1 flex flex-col"
      >
        <TabsList className="grid grid-cols-3 mx-4 mt-4">
          <TabsTrigger value="private">
            <User size={16} className="mr-2" />
            Private
          </TabsTrigger>
          <TabsTrigger value="groups">
            <Users size={16} className="mr-2" />
            Groups
          </TabsTrigger>
          <TabsTrigger value="meetings">
            <CalendarClock size={16} className="mr-2" />
            Meetings
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="private" className="flex-1 pt-4">
          <ScrollArea className="flex-1 h-[calc(100vh-220px)]">
            <div className="space-y-1 px-1">
              {filteredPrivateChats.map((chat) => (
                <button
                  key={chat.id}
                  className={`w-full px-3 py-2 text-left hover:bg-muted/50 rounded-md flex items-start ${chat.isActive ? 'bg-muted' : ''}`}
                  onClick={() => handleChatSelect('private', chat.id)}
                >
                  <div className="relative mr-3 mt-0.5">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src="" />
                      <AvatarFallback>{chat.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    {chat.online && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-background"></span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <span className={`${chat.unread > 0 ? 'font-bold' : 'font-medium'} truncate`}>{chat.name}</span>
                      <span className="text-xs text-muted-foreground">{chat.time}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                      {chat.unread > 0 && (
                        <Badge variant="destructive" className="ml-2">
                          {chat.unread}
                        </Badge>
                      )}
                    </div>
                  </div>
                </button>
              ))}
              {filteredPrivateChats.length === 0 && (
                <div className="p-4 text-center text-muted-foreground">
                  No matches found
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
        
        <TabsContent value="groups" className="flex-1 pt-4">
          <ScrollArea className="flex-1 h-[calc(100vh-220px)]">
            <div className="space-y-1 px-1">
              {filteredGroupChats.map((chat) => (
                <button
                  key={chat.id}
                  className={`w-full px-3 py-2 text-left hover:bg-muted/50 rounded-md flex items-start ${chat.isActive ? 'bg-muted' : ''}`}
                  onClick={() => handleChatSelect('group', chat.id)}
                >
                  <Avatar className="h-10 w-10 mr-3 mt-0.5">
                    <AvatarFallback className="bg-brand-primary text-white">
                      {chat.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <span className={`${chat.unread > 0 ? 'font-bold' : 'font-medium'} truncate`}>{chat.name}</span>
                      <span className="text-xs text-muted-foreground">{chat.time}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                      {chat.unread > 0 && (
                        <Badge variant="destructive" className="ml-2">
                          {chat.unread}
                        </Badge>
                      )}
                    </div>
                    <div className="mt-1">
                      <span className="text-xs text-muted-foreground">{chat.members} members</span>
                    </div>
                  </div>
                </button>
              ))}
              {filteredGroupChats.length === 0 && (
                <div className="p-4 text-center text-muted-foreground">
                  No matches found
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
        
        <TabsContent value="meetings" className="flex-1 pt-4">
          <ScrollArea className="flex-1 h-[calc(100vh-220px)]">
            <div className="space-y-1 px-1">
              {filteredMeetings.map((meeting) => (
                <button
                  key={meeting.id}
                  className={`w-full px-3 py-2 text-left hover:bg-muted/50 rounded-md flex items-start ${meeting.isActive ? 'bg-muted' : ''}`}
                  onClick={() => handleChatSelect('meeting', meeting.id)}
                >
                  <div className="h-10 w-10 rounded-md bg-brand-primary/10 text-brand-primary flex items-center justify-center mr-3">
                    <CalendarClock size={20} />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">{meeting.name}</div>
                    <div className="text-sm text-muted-foreground">{meeting.time}</div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {meeting.participants} participants
                    </div>
                  </div>
                </button>
              ))}
              {filteredMeetings.length === 0 && (
                <div className="p-4 text-center text-muted-foreground">
                  No matches found
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ChatSidebar;
