
import { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
const teamMembers = ['Alice', 'Bob', 'Charlie', 'Dave', 'Eve'];

// Generate sample data
const generateData = () => {
  return teamMembers.map(member => {
    return days.map(day => {
      return {
        member,
        day,
        value: Math.floor(Math.random() * 10) + 1 // 1-10
      };
    });
  }).flat();
};

const WorkloadDistributionChart = () => {
  const [data] = useState(generateData());
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const getColor = (value: number) => {
    if (value <= 3) return '#2a9d8f'; // Low - green
    if (value <= 7) return '#ffb703'; // Medium - yellow
    return '#e63946'; // High - red
  };
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const cellSize = 40;
    const padding = 40;
    
    // Set canvas size
    canvas.width = days.length * cellSize + padding * 2;
    canvas.height = teamMembers.length * cellSize + padding * 2;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw labels
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#000';
    
    // Draw day labels (x-axis)
    days.forEach((day, i) => {
      ctx.fillText(day, padding + i * cellSize + cellSize / 2, padding / 2);
    });
    
    // Draw team member labels (y-axis)
    teamMembers.forEach((member, i) => {
      ctx.fillText(member, padding / 2, padding + i * cellSize + cellSize / 2);
    });
    
    // Draw heatmap cells
    data.forEach(item => {
      const x = padding + days.indexOf(item.day) * cellSize;
      const y = padding + teamMembers.indexOf(item.member) * cellSize;
      
      ctx.fillStyle = getColor(item.value);
      ctx.fillRect(x, y, cellSize, cellSize);
      
      // Draw value text
      ctx.fillStyle = '#fff';
      ctx.fillText(item.value.toString(), x + cellSize / 2, y + cellSize / 2);
    });
    
  }, [data]);
  
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle>Workload Distribution</CardTitle>
        <CardDescription>Team workload across weekdays</CardDescription>
      </CardHeader>
      <CardContent className="flex justify-center">
        <div className="overflow-auto">
          <canvas ref={canvasRef} />
        </div>
      </CardContent>
    </Card>
  );
};

export default WorkloadDistributionChart;
