
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const data = [
  { name: 'Jan', bugs: 4, features: 2, docs: 6 },
  { name: 'Feb', bugs: 3, features: 5, docs: 3 },
  { name: 'Mar', bugs: 2, features: 3, docs: 4 },
  { name: 'Apr', bugs: 5, features: 4, docs: 3 },
  { name: 'May', bugs: 1, features: 6, docs: 5 },
  { name: 'Jun', bugs: 3, features: 4, docs: 2 },
];

const CompletedWorkChart = () => {
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle>Completed Work Overview</CardTitle>
        <CardDescription>Tasks completed by category</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white',
                  border: '1px solid #ccc',
                  borderRadius: '5px'
                }} 
              />
              <Legend />
              <Bar dataKey="bugs" name="Bugs Fixed" stackId="a" fill="#e63946" />
              <Bar dataKey="features" name="Features Developed" stackId="a" fill="#4361ee" />
              <Bar dataKey="docs" name="Documents Completed" stackId="a" fill="#2a9d8f" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default CompletedWorkChart;
